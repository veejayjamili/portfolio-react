# VJ Portfolio — React + Tailwind CSS

A responsive portfolio converted to React with Vite and Tailwind CSS. The original visual design and custom responsive styles are retained, with the page rendered through a React component. Tailwind is configured and ready for utility-first styling as the project evolves.

## Requirements
- Node.js 20.19+ or 22.12+
- npm

## Run locally
```bash
npm install
npm run dev
```
Open the local URL printed by Vite.

## Production build
```bash
npm run build
npm run preview
```
The production site is generated in `dist/`.

## Deploy to Vercel
1. Push this project folder to a GitHub, GitLab, or Bitbucket repository.
2. In Vercel, choose **Add New → Project** and import the repository.
3. Vercel should detect Vite. Confirm these settings:
   - Framework Preset: **Vite**
   - Build Command: `npm run build`
   - Output Directory: `dist`
4. Click **Deploy**. The included `vercel.json` provides the build and output settings.

You can also deploy from the project folder using the Vercel CLI: `npx vercel`, then `npx vercel --prod`.

## Customize before publishing
- Replace `hello@yourdomain.com` with your real contact email in `src/App.jsx`.
- Replace illustrative project previews with approved screenshots if available.
- Confirm project descriptions and experience details.
- Project logos use LogoAPI.sh and technology logos use Simple Icons CDN, so they need an internet connection.

## Project structure
```text
public/              Static assets (add yours here)
src/
  App.jsx            Main React portfolio component
  main.jsx           React entry point
  index.css          Tailwind directives + portfolio styling
index.html           Vite HTML entry
tailwind.config.js   Tailwind content configuration
postcss.config.js    Tailwind/PostCSS configuration
vite.config.js       Vite configuration
vercel.json          Vercel deployment settings
```
