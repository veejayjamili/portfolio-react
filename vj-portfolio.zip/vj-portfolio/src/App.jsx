import { useEffect, useState } from 'react';

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const items = document.querySelectorAll('.reveal');
    if (!('IntersectionObserver' in window)) {
      items.forEach((item) => item.classList.add('is-visible'));
      return;
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    items.forEach((item) => observer.observe(item));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const moveGlow = (event) => {
      const glow = document.querySelector('.cursor-glow');
      if (glow) { glow.style.left = `${event.clientX}px`; glow.style.top = `${event.clientY}px`; }
    };
    if (window.matchMedia('(pointer: fine)').matches) window.addEventListener('pointermove', moveGlow);
    const onKeyDown = (event) => { if (event.key === 'Escape') setMenuOpen(false); };
    document.addEventListener('keydown', onKeyDown);
    return () => { window.removeEventListener('pointermove', moveGlow); document.removeEventListener('keydown', onKeyDown); };
  }, []);

  useEffect(() => {
    document.body.classList.toggle('menu-open', menuOpen);
    return () => document.body.classList.remove('menu-open');
  }, [menuOpen]);

  return (
    <div className="min-h-screen bg-[#10120f] text-[#f1f2eb]">

  <div className="noise" aria-hidden="true"></div>
  <div className="cursor-glow" aria-hidden="true"></div>

  <header className="site-header">
    <a className="brand" href="#home" aria-label="VJ home"><img src="/vj-logo.svg" alt="VJ logo" /></a>
    <nav className="desktop-nav" aria-label="Main navigation">
      <a href="#about">About</a>
      <a href="#career">Career</a>
      <a href="#work">Selected work</a>
      <a href="#expertise">Expertise</a>
      <a href="#contact">Contact</a>
    </nav>
    <a className="availability" href="#contact"><span className="status-dot"></span> Available for select projects <span className="arrow">↗</span></a>
    <button className="menu-toggle" aria-label={menuOpen ? "Close navigation" : "Open navigation"} aria-expanded={menuOpen} onClick={() => setMenuOpen((open) => !open)}><span></span><span></span></button>
  </header>

  <main>
    <section className="hero section-wrap" id="home">
      <div className="hero-meta reveal">
        <span className="eyebrow"><span className="eyebrow-line"></span> INDEPENDENT FRONTEND DEVELOPER</span>
        <span className="hero-location">BASED IN THE PHILIPPINES <span className="crosshair">✳</span></span>
      </div>

      <div className="hero-content">
        <p className="hero-kicker reveal">I turn good ideas into</p>
        <h1 className="hero-title reveal">
          <span>GOOD</span>
          <span className="title-second">DIGITAL <i>experiences.</i></span>
        </h1>
        <div className="hero-bottom reveal">
          <p className="hero-intro">I’m Veejay — a frontend developer focused on building thoughtful, responsive and easy-to-use websites that look sharp and work beautifully.</p>
          <a className="round-link" href="#work" aria-label="Explore selected work"><span>↓</span></a>
          <div className="hero-index"><span>SCROLL TO EXPLORE</span><span className="index-line"></span><span>01 / 05</span></div>
        </div>
      </div>

      <div className="hero-art reveal" aria-label="Abstract decorative graphic">
        <div className="orbit orbit-one"></div><div className="orbit orbit-two"></div>
        <div className="orbit-core"><span>VJ</span><small>FRONTEND<br />DEVELOPER</small></div>
        <span className="orbit-label label-top">DESIGN × CODE</span>
        <span className="orbit-label label-bottom">DETAIL MATTERS.</span>
        <span className="orbit-star">✳</span>
      </div>

      <div className="hero-foot reveal">
        <span>SCROLL A LITTLE. STAY A WHILE.</span>
        <span>HTML / CSS / JS / WORDPRESS</span>
      </div>
    </section>

    <section className="marquee" aria-label="Areas of focus">
      <div className="marquee-track">
        <span>FRONTEND DEVELOPMENT <b>✳</b> RESPONSIVE DESIGN <b>✳</b> WORDPRESS <b>✳</b> UI IMPLEMENTATION <b>✳</b> FRONTEND DEVELOPMENT <b>✳</b> RESPONSIVE DESIGN <b>✳</b> WORDPRESS <b>✳</b> UI IMPLEMENTATION <b>✳</b></span>
      </div>
    </section>

    <section className="intro section-wrap section-pad" id="about">
      <div className="section-label reveal"><span>01</span> / A LITTLE INTRO</div>
      <div className="intro-grid">
        <h2 className="section-heading reveal">I care about the <em>details</em> that make a website feel right.</h2>
        <div className="intro-copy reveal">
          <p className="lead">Good frontend work is more than making a design look the same in a browser. It’s about making the experience feel natural on every screen.</p>
          <p>I’m a frontend developer with 7+ years of experience building and maintaining websites and web applications. I enjoy turning designs into clean, responsive interfaces, solving real-world UI problems, and making existing websites better.</p>
          <a className="text-link" href="#contact">A little more about working together <span>↗</span></a>
        </div>
      </div>
      <div className="stats-row reveal">
        <div className="stat"><strong>07<span>+</span></strong><small>YEARS BUILDING FOR THE WEB</small></div>
        <div className="stat"><strong>01<span>×</span></strong><small>DETAIL-DRIVEN MINDSET</small></div>
        <div className="stat"><strong>∞</strong><small>CURIOSITY TO KEEP LEARNING</small></div>
      </div>
    </section>

    <section className="career section-wrap section-pad" id="career">
      <div className="section-top reveal">
        <div className="section-label"><span>02</span> / CAREER JOURNEY</div>
        <p>A look at the teams I’ve worked with and the experience I’ve built along the way.</p>
      </div>
      <div className="career-list">
        <article className="career-entry reveal">
          <div className="career-marker"><span></span></div>
          <div className="career-meta"><span className="career-period">JUNE 2024 – JULY 2026</span><span className="career-type">E-LEARNING · WEB APPLICATIONS</span></div>
          <div className="career-content">
            <div className="career-heading"><div><h3>Frontend Analyst & Technical Lead</h3><p className="career-company">Forty Degrees Celsius, Inc.</p></div><span className="career-index">01</span></div>
            <p className="career-description">Led and supported frontend development for production e-learning platforms, guided UI implementation, coordinated technical work, and helped resolve responsive, interface, and localization issues.</p>
            <div className="career-tags"><span>Frontend Leadership</span><span>UI Development</span><span>Localization</span><span>Production Support</span></div>
          </div>
        </article>
        <article className="career-entry reveal">
          <div className="career-marker"><span></span></div>
          <div className="career-meta"><span className="career-period">AUGUST 2022 – JUNE 2024</span><span className="career-type">E-LEARNING · WEB APPLICATIONS</span></div>
          <div className="career-content">
            <div className="career-heading"><div><h3>Frontend Developer</h3><p className="career-company">Forty Degrees Celsius, Inc.</p></div><span className="career-index">02</span></div>
            <p className="career-description">Developed and maintained production e-learning platforms, improved responsive layouts, implemented design updates, and fixed website UI and localization issues.</p>
            <div className="career-tags"><span>Frontend Development</span><span>Responsive Design</span><span>UI Improvements</span><span>Localization</span></div>
          </div>
        </article>
        <article className="career-entry reveal">
          <div className="career-marker"><span></span></div>
          <div className="career-meta"><span className="career-period">MARCH 2019 – AUGUST 2022</span><span className="career-type">WORDPRESS · CLIENT WEBSITES</span></div>
          <div className="career-content">
            <div className="career-heading"><div><h3>Web Developer</h3><p className="career-company">Proweaver, Inc.</p></div><span className="career-index">03</span></div>
            <p className="career-description">Built and maintained WordPress websites for different clients, translated Figma and Adobe XD designs into responsive pages, and customized themes, plugins, and page builders.</p>
            <div className="career-tags"><span>WordPress</span><span>Elementor</span><span>Divi</span><span>WPBakery</span><span>Website Maintenance</span></div>
          </div>
        </article>
      </div>
      <p className="career-note">Want the full details? <a href="#contact">Get in touch <span>↗</span></a> and I’ll be happy to share my resume.</p>
    </section>

    <section className="work section-wrap section-pad" id="work">
      <div className="section-top reveal">
        <div className="section-label"><span>03</span> / SELECTED WORK</div>
        <p>A few projects and platforms that show how I think, build and improve digital experiences.</p>
      </div>
      <div className="work-grid">
        <article className="project-card project-feature reveal">
          <a className="project-visual visual-learning" href="https://fdc-inc.com/" target="_blank" rel="noopener noreferrer" aria-label="Visit Forty Degrees Celsius website">
            <div className="visual-top"><span>01 — CORPORATE WEBSITE</span><span>↗</span></div>
            <div className="project-brand-mark"><img src="https://logoapi.sh/fdc-inc.com.svg" alt="Forty Degrees Celsius logo" loading="lazy" /><span>FORTY DEGREES CELSIUS</span></div>
            <div className="learning-window fdc-preview">
              <div className="window-bar"><i></i><i></i><i></i><span>fdc-inc.com</span></div>
              <div className="fdc-preview-content"><small>FORTY DEGREES CELSIUS INC.</small><b>Innovative<br />IT solutions.</b><span>DESIGN · TECHNOLOGY · PEOPLE</span><div className="fdc-preview-line"></div></div>
            </div>
            <span className="visual-caption">CORPORATE WEB EXPERIENCE</span>
          </a>
          <div className="project-info"><div><h3>Forty Degrees Celsius</h3><p>Frontend development · UI improvements · Web support</p></div><span className="project-number">01 / 03</span></div>
        </article>
        <article className="project-card reveal">
          <a className="project-visual visual-wordpress" href="https://www.proweaver.com/" target="_blank" rel="noopener noreferrer" aria-label="Visit Proweaver website">
            <div className="visual-top"><span>02 — WORDPRESS / WEB DEVELOPMENT</span><span>↗</span></div>
            <div className="project-brand-mark"><img src="https://logoapi.sh/proweaver.com.svg" alt="Proweaver logo" loading="lazy" /><span>PROWEAVER</span></div>
            <div className="wp-mock">
              <div className="wp-nav"><b>PROWEAVER</b><span>ABOUT　 SERVICES　 CONTACT</span></div>
              <div className="wp-copy"><small>YOUR DIGITAL PARTNER</small><b>Build your<br /><i>online presence.</i></b><span className="wp-pill">EXPLORE SERVICES ↗</span></div>
              <div className="wp-shape"></div>
            </div>
            <span className="visual-caption">WORDPRESS & WEBSITE DEVELOPMENT</span>
          </a>
          <div className="project-info"><div><h3>Proweaver</h3><p>WordPress · Responsive websites · Site maintenance</p></div><span className="project-number">02 / 03</span></div>
        </article>
        <article className="project-card reveal">
          <a className="project-visual visual-yacht" href="https://zenithyachtcharters.com/" target="_blank" rel="noopener noreferrer" aria-label="Visit Zenith Yacht Charters website">
            <div className="visual-top"><span>03 — WEB DESIGN / DEVELOPMENT</span><span>↗</span></div>
            <div className="project-brand-mark"><img src="https://logoapi.sh/zenithyachtcharters.com.svg" alt="Zenith Yacht Charters logo" loading="lazy" /><span>ZENITH YACHT CHARTERS</span></div>
            <div className="yacht-mock"><span>ZENITH <i>YACHT CHARTERS</i></span><b>FIND YOUR<br />HORIZON.</b><small>PRIVATE LUXURY YACHT CHARTERS</small><div className="yacht-cta">EXPLORE THE FLEET ↗</div></div>
            <span className="visual-caption">LUXURY CHARTER WEBSITE</span>
          </a>
          <div className="project-info"><div><h3>Zenith Yacht Charters</h3><p>Landing page · Responsive UI · WordPress development</p></div><span className="project-number">03 / 03</span></div>
        </article>
      </div>
    </section>

    <section className="expertise section-wrap section-pad" id="expertise">
      <div className="section-top reveal">
        <div className="section-label"><span>04</span> / WHAT I BRING</div>
        <p>From the first layout to the final browser check, I care about the whole experience.</p>
      </div>
      <div className="expertise-list">
        <div className="expertise-item reveal"><span className="expertise-no">01</span><h3>Frontend development</h3><p>Responsive, accessible interfaces built with care for the small details.</p><span className="expertise-arrow">↗</span></div>
        <div className="expertise-item reveal"><span className="expertise-no">02</span><h3>WordPress development</h3><p>Custom page builds, theme styling, builder customization and ongoing maintenance.</p><span className="expertise-arrow">↗</span></div>
        <div className="expertise-item reveal"><span className="expertise-no">03</span><h3>UI implementation</h3><p>Turning Figma and Adobe XD designs into accurate, polished web experiences.</p><span className="expertise-arrow">↗</span></div>
        <div className="expertise-item reveal"><span className="expertise-no">04</span><h3>Optimization & support</h3><p>Debugging, performance improvements, cross-browser checks and production fixes.</p><span className="expertise-arrow">↗</span></div>
      </div>
      <div className="stack-block reveal">
        <span className="eyebrow">TOOLS I WORK WITH</span>
        <div className="stack-grid" aria-label="Technologies and tools">
          <div className="stack-item"><img src="https://cdn.simpleicons.org/html5/E34F26" alt="HTML5 logo" loading="lazy" /><span>HTML5</span></div>
          <div className="stack-item"><img src="https://cdn.simpleicons.org/css3/1572B6" alt="CSS3 logo" loading="lazy" /><span>CSS3</span></div>
          <div className="stack-item"><img src="https://cdn.simpleicons.org/javascript/F7DF1E" alt="JavaScript logo" loading="lazy" /><span>JavaScript</span></div>
          <div className="stack-item"><img src="https://cdn.simpleicons.org/react/61DAFB" alt="React logo" loading="lazy" /><span>React</span></div>
          <div className="stack-item"><img src="https://cdn.simpleicons.org/typescript/3178C6" alt="TypeScript logo" loading="lazy" /><span>TypeScript</span></div>
          <div className="stack-item"><img src="https://cdn.simpleicons.org/jquery/0769AD" alt="jQuery logo" loading="lazy" /><span>jQuery</span></div>
          <div className="stack-item"><img src="https://cdn.simpleicons.org/wordpress/21759B" alt="WordPress logo" loading="lazy" /><span>WordPress</span></div>
          <div className="stack-item"><img src="https://cdn.simpleicons.org/php/777BB4" alt="PHP logo" loading="lazy" /><span>PHP</span></div>
          <div className="stack-item"><img src="https://cdn.simpleicons.org/mysql/4479A1" alt="MySQL logo" loading="lazy" /><span>MySQL</span></div>
          <div className="stack-item"><img src="https://cdn.simpleicons.org/sass/CC6699" alt="Sass logo" loading="lazy" /><span>SCSS</span></div>
          <div className="stack-item"><img src="https://cdn.simpleicons.org/tailwindcss/06B6D4" alt="Tailwind CSS logo" loading="lazy" /><span>Tailwind CSS</span></div>
          <div className="stack-item"><img src="https://cdn.simpleicons.org/figma/F24E1E" alt="Figma logo" loading="lazy" /><span>Figma</span></div>
          <div className="stack-item"><img src="https://cdn.simpleicons.org/adobexd/FF61F6" alt="Adobe XD logo" loading="lazy" /><span>Adobe XD</span></div>
          <div className="stack-item"><img src="https://cdn.simpleicons.org/adobephotoshop/31A8FF" alt="Adobe Photoshop logo" loading="lazy" /><span>Photoshop</span></div>
          <div className="stack-item"><img src="https://cdn.simpleicons.org/git/F05032" alt="Git logo" loading="lazy" /><span>Git</span></div>
        </div>
      </div>
    </section>

    <section className="contact section-wrap section-pad" id="contact">
      <div className="section-label reveal"><span>05</span> / HAVE A PROJECT IN MIND?</div>
      <div className="contact-main reveal">
        <h2>LET’S MAKE<br />SOMETHING <em>MATTER.</em></h2>
        <a className="contact-circle" href="mailto:veejayjamili@gmail.com" aria-label="Email VJ"><span>LET’S<br />TALK</span><b>↗</b></a>
      </div>
      <div className="contact-bottom reveal">
        <p>Have a website to build, improve or bring back to life? I’d love to hear about it.</p>
        <a className="email-link" href="mailto:veejayjamili@gmail.com">veejayjamili@gmail.com <span>↗</span></a>
      </div>
    </section>
  </main>

  <footer className="site-footer section-wrap">
    <a className="brand" href="#home" aria-label="Back to top"><img src="/vj-logo.svg" alt="VJ logo" /></a>
    <span>DESIGNED & BUILT WITH CARE.</span>
    <span>© {new Date().getFullYear()} VJ — ALL RIGHTS RESERVED.</span>
    <a href="#home" className="back-top">BACK TO TOP ↑</a>
  </footer>

  <div className={`mobile-menu${menuOpen ? " open" : ""}`} aria-hidden={!menuOpen}>
    <a href="#about" onClick={() => setMenuOpen(false)}>About <span>01</span></a><a href="#career" onClick={() => setMenuOpen(false)}>Career <span>02</span></a><a href="#work" onClick={() => setMenuOpen(false)}>Selected work <span>03</span></a><a href="#expertise" onClick={() => setMenuOpen(false)}>Expertise <span>04</span></a><a href="#contact" onClick={() => setMenuOpen(false)}>Contact <span>05</span></a>
  </div>

    </div>
  );
}
